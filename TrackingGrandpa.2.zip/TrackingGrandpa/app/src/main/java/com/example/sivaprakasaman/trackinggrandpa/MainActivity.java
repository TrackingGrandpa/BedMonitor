package com.example.sivaprakasaman.trackinggrandpa;

//Copyright (c) Microsoft Corporation All rights reserved.
//
//MIT License:
//
//Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
//documentation files (the  "Software"), to deal in the Software without restriction, including without limitation
//the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
//to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
//The above copyright notice and this permission notice shall be included in all copies or substantial portions of
//the Software.
//
//THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
//CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
//IN THE SOFTWARE.

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.microsoft.band.BandClient;
import com.microsoft.band.BandClientManager;
import com.microsoft.band.BandException;
import com.microsoft.band.BandIOException;
import com.microsoft.band.BandInfo;
import com.microsoft.band.ConnectionState;
import com.microsoft.band.UserConsent;
import com.microsoft.band.sensors.BandAccelerometerEvent;
import com.microsoft.band.sensors.BandAccelerometerEventListener;
import com.microsoft.band.sensors.BandHeartRateEvent;
import com.microsoft.band.sensors.BandHeartRateEventListener;
import com.microsoft.band.sensors.SampleRate;


import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.app.Activity;
import android.os.AsyncTask;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends Activity { //Main class must extend activity

    private BandClient client = null; //initialize BandClient
    private Button btnFallSensor; //start button
    private Button btnBedMonitor;
    private Button btnHeartRate;
    private Button btnSettings;
    //insert other parts of xml here
    //private TextView txtStatus; //Where results will be displayed


    private BandAccelerometerEventListener mAccelerometerEventListener = new BandAccelerometerEventListener() { //declares new accelerometer event listener with the following:
        @Override
        public void onBandAccelerometerChanged(final BandAccelerometerEvent event) { //takes in a BandAccelerometerEvent
            if (event != null) { //if the event isn't null
                appendToUI(String.format(" X = %.3f \n Y = %.3f\n Z = %.3f", event.getAccelerationX(),
                        event.getAccelerationY(), event.getAccelerationZ())); //displays acceleration

            }
        }
    };

    private BandHeartRateEventListener mHeartRateEventListener = new BandHeartRateEventListener() {
        @Override
        public void onBandHeartRateChanged(final BandHeartRateEvent event) {
            if (event != null) {
                appendToUI(String.format("Heart Rate = %d beats per minute\n"
                        + "Quality = %s\n", event.getHeartRate(), event.getQuality()));
            }
        }
    };

    //insert HR event listener here, insert Distance event listener here


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); //sets our xml as the content view

        //button mappings
        btnHeartRate = (Button) findViewById(R.id.toHRScreen); //links button to variable
        btnFallSensor = (Button) findViewById(R.id.toFallDetector); //links button to variable
        btnBedMonitor = (Button) findViewById(R.id.toBedMonitor); //links button to variable
        btnSettings = (Button) findViewById(R.id.toSettings); //links button to variable

        new HeartRateSubscriptionTask().execute();
        new AccelerometerSubscriptionTask().execute();

        btnHeartRate.setOnClickListener(new View.OnClickListener() {//when you click btnSwitchScreen
            @Override
            public void onClick(View v) { //takes our view when we click this button
                Intent nextScreenHR = new Intent(getApplicationContext(), HeartRate.class);
                startActivity(nextScreenHR);
            }
        });

        btnFallSensor.setOnClickListener(new View.OnClickListener() {//when you click btnSwitchScreen
            @Override
            public void onClick(View v) { //takes our view when we click this button
                Intent nextScreenFS = new Intent(getApplicationContext(), FallSensor.class);
                startActivity(nextScreenFS);
            }
        });

        btnBedMonitor.setOnClickListener(new View.OnClickListener() {//when you click btnSwitchScreen
            @Override
            public void onClick(View v) { //takes our view when we click this button
                Intent nextScreenBM = new Intent(getApplicationContext(), HeartRate.class);
                startActivity(nextScreenBM);
            }
        });

        btnSettings.setOnClickListener(new View.OnClickListener() {//when you click btnSwitchScreen
            @Override
            public void onClick(View v) { //takes our view when we click this button
                Intent nextScreenSettings = new Intent(getApplicationContext(), HeartRate.class);
                startActivity(nextScreenSettings);
            }
        });

    }

    @Override
    protected void onResume() { //resuming... semiCopy need to change reset method
        super.onResume(); //does what normal apps do
        //txtStatus.setText(""); //but also resets the text box
    }

    @Override
    protected void onPause() { //if you pause it  semiCopy
        super.onPause(); //do what normal apps do
        if (client != null) { //if we have a band client connected
            try { //unregister our accelerometerEventListener
                client.getSensorManager().unregisterAccelerometerEventListener(mAccelerometerEventListener);
            } catch (BandIOException e) {  //IO exception; band can't in/out, we dont have one?
                appendToUI(e.getMessage()); //display exception
            }
        }
    }





    private class AccelerometerSubscriptionTask extends AsyncTask<Void, Void, Void> {
        //AccelerometerSubscriptionTask is a type of an asynctask
        @Override
        protected Void doInBackground(Void... params) { //do in background...? so like always? mostlyCopy
            try {
                if (getConnectedBandClient()) {//if we have a connected band client
                    appendToUI("Band is connected.\n"); //we say so; note AppendToUI shows in the display
                    client.getSensorManager().registerAccelerometerEventListener(mAccelerometerEventListener, SampleRate.MS128);
                } else {
                    appendToUI("Band isn't connected. Please make sure bluetooth is on and the band is in range.\n");
                }
            } catch (BandException e) {
                String exceptionMessage = "";
                switch (e.getErrorType()) {
                    case UNSUPPORTED_SDK_VERSION_ERROR:
                        exceptionMessage = "Microsoft Health BandService doesn't support your SDK Version. Please update to latest SDK.\n";
                        break;
                    case SERVICE_ERROR:
                        exceptionMessage = "Microsoft Health BandService is not available. Please make sure Microsoft Health is installed and that you have the correct permissions.\n";
                        break;
                    default:
                        exceptionMessage = "Unknown error occured: " + e.getMessage() + "\n";
                        break;
                }
                appendToUI(exceptionMessage);

            } catch (Exception e) {
                appendToUI(e.getMessage());
            }
            return null; //why
        }
    }

    private class HeartRateSubscriptionTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            try {
                if (getConnectedBandClient()) {
                    if (true) {
                        client.getSensorManager().registerHeartRateEventListener(mHeartRateEventListener);
                    } else {
                        appendToUI("You have not given this application consent to access heart rate data yet."
                                + " Please press the Heart Rate Consent button.\n");
                    }
                } else {
                    appendToUI("Band isn't connected. Please make sure bluetooth is on and the band is in range.\n");
                }
            } catch (BandException e) {
                String exceptionMessage="";
                switch (e.getErrorType()) {
                    case UNSUPPORTED_SDK_VERSION_ERROR:
                        exceptionMessage = "Microsoft Health BandService doesn't support your SDK Version. Please update to latest SDK.\n";
                        break;
                    case SERVICE_ERROR:
                        exceptionMessage = "Microsoft Health BandService is not available. Please make sure Microsoft Health is installed and that you have the correct permissions.\n";
                        break;
                    default:
                        exceptionMessage = "Unknown error occured: " + e.getMessage() + "\n";
                        break;
                }
                //appendToUI(exceptionMessage);

            } catch (Exception e) {
                //appendToUI(e.getMessage());
            }
            return null;
        }
    }

    @Override
    protected void onDestroy() { //if you x out? DirectCopy but ultimately we want it always running
        if (client != null) { //if we have a client
            try {
                client.disconnect().await(); //no clue, disconnects but what's await?
            } catch (InterruptedException e) {
                // Do nothing as this is happening during destroy
            } catch (BandException e) {
                // Do nothing as this is happening during destroy
            }
        }
        super.onDestroy();
    }

    private void appendToUI(final String string) { //used to edit UI continuously; semiCopy
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() { //so when we appendToUI, we make a new thread(?), then do what we want
                //txtStatus.setText(string);
            }
        });
    }

    private boolean getConnectedBandClient() throws InterruptedException, BandException {
        if (client == null) { //if we don't have a client
            BandInfo[] devices = BandClientManager.getInstance().getPairedBands(); //gets paired bands
            if (devices.length == 0) { //if we don't have any bands paired there
                appendToUI("Band isn't paired with your phone.\n");
                return false; //failed to get connected Band
            }
            client = BandClientManager.getInstance().create(getBaseContext(), devices[0]);
            //long as we have a band, set our client equal to the first one
        } else if (ConnectionState.CONNECTED == client.getConnectionState()) {
            return true;
        }

        appendToUI("Band is connecting...\n");
        return ConnectionState.CONNECTED == client.connect().await();
    }
}

