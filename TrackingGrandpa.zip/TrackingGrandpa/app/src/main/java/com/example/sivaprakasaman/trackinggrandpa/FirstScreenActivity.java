package com.example.sivaprakasaman.trackinggrandpa;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstScreenActivity extends Activity {
    //EditText inputName;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // inputName = (EditText) findViewById(R.id.name);

        Button btnHR = (Button) findViewById(R.id.toHRScreen);

        //Listening to button event
        btnHR.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent HR = new Intent(getApplicationContext(), SecondScreenActivity.class);

                startActivity(HR);

            }
        });
    }
}