//Copyright (c) Microsoft Corporation All rights reserved.  
// 
//MIT License: 
// 
//Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
//documentation files (the  "Software"), to deal in the Software without restriction, including without limitation
//the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
//to permit persons to whom the Software is furnished to do so, subject to the following conditions: 
// 
//The above copyright notice and this permission notice shall be included in all copies or substantial portions of
//the Software. 
// 
//THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
//CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
//IN THE SOFTWARE.
package com.example.sivaprakasaman.trackinggrandpa;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.microsoft.band.BandClient;
import com.microsoft.band.BandClientManager;
import com.microsoft.band.BandException;
import com.microsoft.band.BandInfo;
import com.microsoft.band.BandIOException;
import com.microsoft.band.ConnectionState;
import com.microsoft.band.sensors.BandAccelerometerEvent;
import com.microsoft.band.sensors.BandAccelerometerEventListener;
import com.microsoft.band.sensors.SampleRate;

import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.app.Activity;
import android.os.AsyncTask;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.PasswordAuthentication;
import java.util.Properties;

public class BandAccelerometerAppActivity extends Activity { //Main class must extend activity

    private BandClient client = null; //initialize BandClient
    private Button btnStart; //start button
    private TextView txtStatus; //Where results will be displayed

    private int switchStartStop = 0; //Adam edit for Henry data
    private int dataIncrementer = 0; //Adam edit for Henry data
    private int storedDataLength = 1000; //Adam edit for Henry
    private double[][] storedData = new double[3][storedDataLength]; //Adam edit for Henry data
    private String outputData = ""; //Adam edit for Henry data

//	private void writeToFile(String data) {
//		try {
//			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("config.txt", Context.MODE_PRIVATE));
//			outputStreamWriter.write(data);
//			outputStreamWriter.close();
//		}
//		catch (IOException e) {
//			Log.e("Exception", "File write failed: " + e.toString());
//		}
//	}

    private BandAccelerometerEventListener mAccelerometerEventListener = new BandAccelerometerEventListener() { //declares new accelerometer event listener with the following:
        @Override
        public void onBandAccelerometerChanged(final BandAccelerometerEvent event) { //takes in a BandAccelerometerEvent
            if (event != null) { //if the event isn't null
                appendToUI(String.format(" X = %.3f \n Y = %.3f\n Z = %.3f", event.getAccelerationX(),
                        event.getAccelerationY(), event.getAccelerationZ())); //displays acceleration
                if (dataIncrementer < storedDataLength) //added for Henry data
                {
                    dataIncrementer++;
                    outputData += String.format("%.3f\t%.3f\t%.3f\n", event.getAccelerationX(),
                            event.getAccelerationY(), event.getAccelerationZ());
                    storedData[0][dataIncrementer] = event.getAccelerationX();
                    storedData[1][dataIncrementer] = event.getAccelerationY();
                    storedData[2][dataIncrementer] = event.getAccelerationZ();

                }

            }
        }
    };
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client2;


    @Override
    protected void onCreate(Bundle savedInstanceState) { //sets initial layout? semiCopy
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); //sets our xml as the content view

        txtStatus = (TextView) findViewById(R.id.txtStatus); //links view to variable
        btnStart = (Button) findViewById(R.id.btnStart); //links button to variable
        btnStart.setOnClickListener(new OnClickListener() {//when you click btnStart
            @Override
            public void onClick(View v) { //takes our view
                if (switchStartStop == 0) { //Adam added for data acquisition
                    txtStatus.setText(""); //sets the text to nothing to start
                    switchStartStop++; //means next time we stop
                    new AccelerometerSubscriptionTask().execute(); //executes our new accelerometer subscription
                } else //every other click we stop it
                {

                    try {
                        client.getSensorManager().unregisterAccelerometerEventListener(mAccelerometerEventListener);
                    } catch (BandIOException e) {
                        e.printStackTrace();
                    }

                    appendToUI(outputData);
                    switchStartStop--; //means next time we start
                    outputData = "";


                }
            }
        });
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client2 = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    protected void onResume() { //resuming... semiCopy need to change reset method
        super.onResume(); //does what normal apps do
        txtStatus.setText(""); //but also resets the text box
    }

    @Override
    protected void onPause() { //if you pause it  semiCopy
        super.onPause(); //do what normal apps do
        if (client != null) { //if we have a band client connected
            try { //unregister our accelerometerEventListener
                client.getSensorManager().unregisterAccelerometerEventListener(mAccelerometerEventListener);
            } catch (BandIOException e) {  //IO exception; band can't in/out, we dont have one?
                appendToUI(e.getMessage()); //display exception
            }
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client2.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "BandAccelerometerApp Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.microsoft.band.sdk.sampleapp.accelerometer/http/host/path")
        );
        AppIndex.AppIndexApi.start(client2, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "BandAccelerometerApp Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.microsoft.band.sdk.sampleapp.accelerometer/http/host/path")
        );
        AppIndex.AppIndexApi.end(client2, viewAction);
        client2.disconnect();
    }

    //end of accelerometer appactivity class

    private class AccelerometerSubscriptionTask extends AsyncTask<Void, Void, Void> {
        //AccelerometerSubscriptionTask is a type of an asynctask
        @Override
        protected Void doInBackground(Void... params) { //do in background...? so like always? mostlyCopy
            try {
                if (getConnectedBandClient()) {//if we have a connected band client
                    appendToUI("Band is connected.\n"); //we say so; note AppendToUI shows in the display
                    client.getSensorManager().registerAccelerometerEventListener(mAccelerometerEventListener, SampleRate.MS128);
                } else {
                    appendToUI("Band isn't connected. Please make sure bluetooth is on and the band is in range.\n");
                }
            } catch (BandException e) {
                String exceptionMessage = "";
                switch (e.getErrorType()) {
                    case UNSUPPORTED_SDK_VERSION_ERROR:
                        exceptionMessage = "Microsoft Health BandService doesn't support your SDK Version. Please update to latest SDK.\n";
                        break;
                    case SERVICE_ERROR:
                        exceptionMessage = "Microsoft Health BandService is not available. Please make sure Microsoft Health is installed and that you have the correct permissions.\n";
                        break;
                    default:
                        exceptionMessage = "Unknown error occured: " + e.getMessage() + "\n";
                        break;
                }
                appendToUI(exceptionMessage);

            } catch (Exception e) {
                appendToUI(e.getMessage());
            }
            return null; //why
        }
    }

    @Override
    protected void onDestroy() { //if you x out? DirectCopy but ultimately we want it always running
        if (client != null) { //if we have a client
            try {
                client.disconnect().await(); //no clue, disconnects but what's await?
            } catch (InterruptedException e) {
                // Do nothing as this is happening during destroy
            } catch (BandException e) {
                // Do nothing as this is happening during destroy
            }
        }
        super.onDestroy();
    }

    private void appendToUI(final String string) { //used to edit UI continuously; semiCopy
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() { //so when we appendToUI, we make a new thread(?), then do what we want
                txtStatus.setText(string);
            }
        });
    }

    private boolean getConnectedBandClient() throws InterruptedException, BandException {
        if (client == null) { //if we don't have a client
            BandInfo[] devices = BandClientManager.getInstance().getPairedBands(); //gets paired bands
            if (devices.length == 0) { //if we don't have any bands paired there
                appendToUI("Band isn't paired with your phone.\n");
                return false; //failed to get connected Band
            }
            client = BandClientManager.getInstance().create(getBaseContext(), devices[0]);
            //long as we have a band, set our client equal to the first one
        } else if (ConnectionState.CONNECTED == client.getConnectionState()) {
            return true;
        }

        appendToUI("Band is connecting...\n");
        return ConnectionState.CONNECTED == client.connect().await();
    }
}

