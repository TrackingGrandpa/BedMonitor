package com.example.sivaprakasaman.trackinggrandpa;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


}

/*public class activity_Main extends Activity {
    // main screen

    @Override
    Button btnHR = (Button)findViewById(R.id.toHRScreen);
    Button btnBed = (Button)findViewById(R.id.toBedMonitor);
    Button btnFall = (Button)findViewById(R.id.toFallDetector);

    btnHR.setOnClickListener(new View.OnClickListener() {

        public void onClick(View arg0){
        //Starting a new Intent
        Intent HRScreen = new Intent(getApplicationContext(), heartrate.xml);
        startActivity(HRScreen);
    }

    });
        btnBed.setOnClickListener(new View.OnClickListener() {


        }

} */






