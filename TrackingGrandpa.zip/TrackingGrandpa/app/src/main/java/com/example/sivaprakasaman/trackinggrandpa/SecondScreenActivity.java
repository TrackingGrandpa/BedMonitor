package com.example.sivaprakasaman.trackinggrandpa;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class SecondScreenActivity extends Activity {
    //EditText inputName;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.heartrate);

        // inputName = (EditText) findViewById(R.id.name);

        Button btnHR = (Button) findViewById(R.id.toHRScreen);

        //Listening to button event
        /*btnHR.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent HR = new Intent(getApplicationContext(), R.layout.heartrate);

                startActivity(HR);

            }
        });*/
    }
}